
# cite as : Issa, A.S., Ali, Y.H. & Rashid, T.A. 
# BCDDO: Binary Child Drawing Development Optimization. J Supercomput (2024). 
# https://doi.org/10.1007/s11227-024-06088-8 

import random
import numpy
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import xgboost as xgb

global X_train, y_train, X_test, y_test

# Read data from an Excel sheet
df = pd.read_excel("feat.xlsx")

# Extract the feature values from the dataframe
X = df.values[:, :-1]
y = df.values[:, -1]

# # Load the Iris dataset
# iris = load_iris()
# print(iris)
# X = iris.data
# y = iris.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
# Function to evaluate the performance of a feature set
# def evaluate_features(X_train, y_train, X_test, y_test, features):
#     # Use the selected features to train a KNN classifier
#     knn = KNeighborsClassifier(n_neighbors=3)
#     knn.fit(X_train[:, features], y_train)
#
#     # Make predictions on the test set
#     y_pred = knn.predict(X_test[:, features])
#
#     # Calculate the accuracy of the classifier
#     accuracy = accuracy_score(y_test, y_pred)
#
#     return accuracy

# def evaluate_features(X_train, y_train, X_test, y_test, features):
#     knn = KNeighborsClassifier(n_neighbors=3)
#     knn.fit(X_train[:, features], y_train)
#     y_pred = knn.predict(X_test[:, features])
#     accuracy = accuracy_score(y_test, y_pred)
#     return accuracy

# def fobj(child):
#     # Use the child to select the features
#     # features = np.where(child > -0.5)[0]
#     features = child.nonzero()[1]
#     print("dddddddddddddddd", len(features))
#     # Evaluate the performance of the feature set
#     accuracy = evaluate_features(features)
#
#     return 1 - accuracy

# Define the objective function
# def evaluate_features(features):
#     mask = np.zeros(X_train.shape[1], dtype=bool)
#     mask[features] = True
#     knn = KNeighborsClassifier(n_neighbors=3)
#     knn.fit(X_train[:, mask], y_train)
#     y_pred = knn.predict(X_test[:, mask])
#     accuracy = accuracy_score(y_test, y_pred)
#     return accuracy

# Define the objective function
def evaluate_features(features):
    mask = np.zeros(X_train.shape[1], dtype=bool)
    feat = features.astype(int)
    # print("eeeeeeeeee",feat)
    mask[feat] = 1
    # print("mmmmmmmmmmm",mask)
    knn = KNeighborsClassifier(n_neighbors=3)
    knn.fit(X_train[:, feat], y_train)
    y_pred = knn.predict(X_test[:, mask])
    accuracy = accuracy_score(y_test, y_pred)
    # print("dddddddd",accuracy)
    return accuracy,feat

# def evaluate_features(features):
#     mask = np.zeros(X_train.shape[1], dtype=bool)
#     features = features.astype(int)
#     mask[features] = 1
#     knn = KNeighborsClassifier(n_neighbors=3)
#     knn.fit(X_train[:, mask], y_train)
#     y_pred = knn.predict(X_test[:, mask])
#     accuracy = accuracy_score(y_test, y_pred)
#     return accuracy, features

def CDDO(itt, fobj, lb, ub, dim):
    n_var = dim
    var_size = [1, n_var]
    var_min = lb
    var_max = ub
    max_it = itt
    n_pop = 3
    lr = 0.01
    sr = 0.9
    t = random.uniform(var_min[0], var_max[0])
    ps = 10
    cr = 0.1
    k = 0
    ncount = 0


    child = [numpy.random.uniform(var_min, var_max, var_size) for _ in range(n_pop)]
    # print("chhhhhhikd",child)

    cp = [numpy.zeros(var_size) for _ in range(ps)]
    # print("cpppppppp", cp)

    GR = [0.0 for _ in range(n_pop)]
    # print("gr",GR)
    # cost = [fobj(c) for c in child]
    # cost = [fobj(c.nonzero()[1]) for c in child]
    # cost, features = [fobj(c.nonzero()[1]) for c in child]
    cost_features = [fobj(c.nonzero()[1]) for c in child]
    cost = [c[0] for c in cost_features]
    sf = [c[1] for c in cost_features]
    print("cost", cost)
    print("sf", sf)
    pbest_cost = cost.copy()

    pbest = [c.copy() for c in child]
    pbest_cost = cost.copy()
    pbest_features = sf.copy()
    gbest = child[0].copy()
    gbest_cost = cost[0]
    gbest_features = sf[0]
    best_costs = numpy.zeros(max_it)
    # print("gbest_features...............", gbest_features)

    best_feat = []
    for it in range(max_it):
        it=it+1
        print("max_it",it)
        best_feature_indices = np.where(gbest > -0.5)[0]
        for i in range(n_pop):

            # print("n_pop",i)
            # print("cost2", pbest_cost[i])
            # print("logical of loop....1",cost[i] > pbest_cost[i])
            if cost[i] >= pbest_cost[i]:
                pbest[i] = child[i].copy()
                pbest_cost[i] = cost[i]
                pbest_features[i] = sf[i]
                # print("gbest_features................1", sf[i])

            if cost[i] >= gbest_cost:

                gbest = child[i].copy()
                gbest_cost = cost[i]

                gbest_features = sf[i]

                child[i] = child[i].squeeze() + 0.2

                GR[i] = child[i][0] + child[i][1] / child[i][0]

                if ncount < n_var:
                    t = t + (t * lr)
                else:
                    t = t - (t * lr)
                    ncount = 0

                if it % 10 == 0:
                    cr = cr + (cr * 0.1)

                p1, p2, p3 = random.sample(range(n_pop), 3)
                child[i] = pbest[p1] + lr * (pbest[p2] - pbest[p3])
                child[i] = child[i] + cr * (gbest - child[i])
                child[i] = numpy.maximum(var_min, child[i])
                child[i] = numpy.minimum(var_max, child[i])
                cost[i] = fobj(child[i].nonzero()[1])
                # print("gbest_features",gbest_features)


            return gbest_features
#
# iris = load_iris()
# X = iris.data
# y = iris.target



lb = numpy.zeros(X_train.shape[1])
ub = numpy.ones(X_train.shape[1])
# best_features = CDDO(itt=1000, fobj=evaluate_features, lb=lb, ub=ub, dim=X_train.shape[1])

# Run CDDO to select the best features

best_features = CDDO(itt=100,fobj=evaluate_features, lb=lb, ub=ub, dim=X_train.shape[1])
# print("dfdfdfdfdf",best_features)
# Convert the binary feature selection mask to a list of indices
# best_features = best_features.astype(bool)
# best_features = numpy.where(best_features)[1]

# Print the selected features
print("FFFFFF",best_features)
#
# # Use the selected features to train a KNN classifier
# knn = KNeighborsClassifier(n_neighbors=3)
# knn.fit(X_train[:, best_features], y_train)
#
# # Convert the binary feature selection array to a boolean mask
# best_features = best_features.astype(bool)
#
# # Get the indices of the selected features
# best_features = np.where(best_features)[0]
#
# # Train a model using the selected features
# knn = KNeighborsClassifier(n_neighbors=3)
# knn.fit(X_train[:, best_features], y_train)
#
# # Test the model using the selected features
# y_pred = knn.predict(X_test[:, best_features])
#
# # Calculate the accuracy of the model
# accuracy = accuracy_score(y_test, y_pred)
# print(" full Accuracy:", accuracy)
#
#
#
# # Create the DMatrix object
# X_fs = X[:, best_features]
# dtrain = xgb.DMatrix(X_train[:, best_features], y_train)
#
# # Define the parameters for the xgboost model
# # params = {'objective': 'binary:logistic', 'max_depth': 10, 'learning_rate': 0.5, 'silent': 1, 'n_estimators': 100}
# params = {}
#
#
# # Train the xgboost model
# clf = xgb.train(params, dtrain)
#
# # Evaluate the xgboost model on the test set
# dtest = xgb.DMatrix(X_test[:, best_features])
# y_pred = clf.predict(dtest)
# y_pred = numpy.round(y_pred)
#
# # Print the accuracy
# accuracy1 = accuracy_score(y_test, y_pred)
# print("Accuracy xgb:", accuracy1)
#
# #Train RF classifier
#
# X_fs = X[:, best_features]
# clf = RandomForestClassifier(n_estimators=100)
# print()
# clf.fit(X_train[:, best_features], y_train)
# y_pred2 = clf.predict(X_test[:, best_features])
# accuracy2 = accuracy_score(y_test, y_pred2)
# print("Accuracy rf:", accuracy2)
