

# cite as : Issa, A.S., Ali, Y.H. & Rashid, T.A. 
# BCDDO: Binary Child Drawing Development Optimization. J Supercomput (2024). 
# https://doi.org/10.1007/s11227-024-06088-8 


# CDDO algorithm
import numpy as np
from numpy.random import rand
from functionHO import Fun
import random

def init_position(lb, ub, N, dim):
    X = np.zeros([N, dim], dtype='float')
    for i in range(N):
        for d in range(dim):
            X[i, d] = lb[0, d] + (ub[0, d] - lb[0, d]) * rand()

    return X


def init_velocity(lb, ub, N, dim):
    V = np.zeros([N, dim], dtype='float')
    Vmax = np.zeros([1, dim], dtype='float')
    Vmin = np.zeros([1, dim], dtype='float')
    # Maximum & minimum velocity
    for d in range(dim):
        Vmax[0, d] = (ub[0, d] - lb[0, d]) / 2
        Vmin[0, d] = -Vmax[0, d]

    for i in range(N):
        for d in range(dim):
            V[i, d] = Vmin[0, d] + (Vmax[0, d] - Vmin[0, d]) * rand()

    return V, Vmax, Vmin


def binary_conversion(X, thres, N, dim):
    Xbin = np.zeros([N, dim], dtype='int')
    for i in range(N):
        for d in range(dim):
            if X[i, d] > thres:
                Xbin[i, d] = 1
            else:
                Xbin[i, d] = 0

    return Xbin


def boundary(x, lb, ub):
    if x < lb:
        x = lb
    if x > ub:
        x = ub

    return x


def jfs(xtrain, ytrain, opts):
    # Parameters
    ub = 1
    lb = 0
    # Dimension
    dim = np.size(xtrain, 1)

    # Parameters of CDDO
    n_var = dim  # Number of Unknown (Decision) Variables
    show_iter_info = True  # Flag for Showing Iteration Information
    # var_size = [1, n_var]  # Matrix Size of Decision Variables
    # var_min = lb  # Lower Bound of Decision Variables
    # var_max = ub  # Upper Bound of Decision Variables
    # max_it = itt  # Maximum Number of Iterations
    n_pop = 100  # Population size
    lr = 0.01  # child level rate
    sr = 0.9  # Child skill rate
    # t = random.uniform(var_min[0], var_max[0])  # random Hand presure
    ps = 10  # pattern matrix size % Constriction Coefficients
    cr = 0.1  # Creativity Rate
    k = 0  # index for the pattern matrix
    thres = 0.5
    ncount = 0



    N = opts['N']
    max_iter = opts['T'] # Maximum Number of Iterations
    # if 'w' in opts:
    #     w = opts['w']
    # if 'c1' in opts:
    #     c1 = opts['c1']
    # if 'c2' in opts:
    #     c2 = opts['c2']

        # Dimension
    dim = np.size(xtrain, 1)
    if np.size(lb) == 1:
        ub = ub * np.ones([1, dim], dtype='float')
        lb = lb * np.ones([1, dim], dtype='float')

    # Initialize position & velocity
    X = init_position(lb, ub, N, dim)
    V, Vmax, Vmin = init_velocity(lb, ub, N, dim)

    # Pre
    fit = np.zeros([N, 1], dtype='float')
    Xgb = np.zeros([1, dim], dtype='float')
    fitG = float('inf')
    Xpb = np.zeros([N, dim], dtype='float')
    fitP = float('inf') * np.ones([N, 1], dtype='float')
    curve = np.zeros([1, max_iter], dtype='float')
    t = 0
    it=0

    while it < max_iter:
        # Binary conversion
        Xbin = binary_conversion(X, thres, N, dim)


        # Fitness
        for i in range(N):
            fit[i, 0] = Fun(xtrain, ytrain, Xbin[i, :], opts)
            if fit[i, 0] < fitP[i, 0]:
                Xpb[i, :] = X[i, :]
                fitP[i, 0] = fit[i, 0]
            if fitP[i, 0] < fitG:
                Xgb[0, :] = Xpb[i, :]
                fitG = fitP[i, 0]

        dim2=len(Xpb)
        GR = [0.0 for _ in range(dim2)]
        # print("dddddddddddddddd",dim2)

        # Store result
        curve[0, it] = fitG.copy()
        print("Iteration:", it + 1)
        print("Best (CDDO):", curve[0, it])
        it += 1
        # print("ddddim",dim)

        for i in range(N):

            for d in range(dim):


                # Select Random Parents
                p1, p2, p3 = random.sample(range(dim2), 3)
                if ncount < n_var:
                    t = t + (t * lr)
                else:
                    t = t - (t * lr)
                    ncount = 0

                if it % 10 == 0:
                    cr = cr + (cr * 0.1)


                V[i, d] = Xpb[p1, d] +lr * (Xpb[p2,d] - Xpb[p3,d])
                # Boundary
                V[i, d] = boundary(V[i, d], Vmin[0, d], Vmax[0, d])
                # Update position
                # X[i, d] = X[i, d] + cr * (Xgb[i, d] - X[i, d])
                # Boundary
                X[i, d] = boundary(X[i, d], lb[0, d], ub[0, d])
                GR[i] = V[i][0] + V[i][1] / V[i][0]

    # Best feature subset
    Gbin = binary_conversion(Xgb, thres, 1, dim)
    Gbin = Gbin.reshape(dim)
    pos = np.asarray(range(0, dim))
    sel_index = pos[Gbin == 1]
    num_feat = len(sel_index)
    # Create dictionary
    pso_data = {'sf': sel_index, 'c': curve, 'nf': num_feat}

    return pso_data









